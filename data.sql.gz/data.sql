-- phpMyAdmin SQL Dump
-- version 4.6.4deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 30, 2016 at 05:25 PM
-- Server version: 10.0.27-MariaDB-0ubuntu0.16.04.1
-- PHP Version: 7.0.8-3ubuntu3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `proposal`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `workplace` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `mobilephone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `title` varchar(150) NOT NULL,
  `etitle` varchar(150) NOT NULL,
  `reason` text NOT NULL,
  `objective` text NOT NULL,
  `orgbenefit` varchar(100) NOT NULL,
  `return1` tinyint(1) NOT NULL DEFAULT '0',
  `return2` tinyint(1) NOT NULL DEFAULT '0',
  `return3` tinyint(1) NOT NULL DEFAULT '0',
  `return4` tinyint(1) NOT NULL DEFAULT '0',
  `return5` tinyint(1) NOT NULL DEFAULT '0',
  `doyear` int(2) DEFAULT '0',
  `domonth` int(2) DEFAULT '0',
  `cost` int(10) NOT NULL,
  `sendother` tinyint(1) DEFAULT '0',
  `sendothertxt` varchar(100) DEFAULT NULL,
  `uploadname` varchar(100) NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `code`, `name`, `workplace`, `address`, `mobilephone`, `email`, `title`, `etitle`, `reason`, `objective`, `orgbenefit`, `return1`, `return2`, `return3`, `return4`, `return5`, `doyear`, `domonth`, `cost`, `sendother`, `sendothertxt`, `uploadname`, `createtime`) VALUES
(1, '', 'วิชานันท์ อุ้นจิตร', 'สวรส', '92/14 Tantong2 Moo6 nongprao-ngai Rd.', '08-6540-1605', 'wichanan@gmail.com', 'การส่งข้อเสนอโครงการจะสำเร็จเมื่่อท่านได้รับอีเมล์ตอบรับจากระบบเท่านั้น', 'trying to make the upload work with IIS on windows', 'trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows', 'trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows trying to make the upload work with IIS on windows ยุทธฯ 2 ส่งเสริมและสนับสนุนการวิจัยและพัฒนาในภาคเอกชน', '', 1, 1, 0, 1, 0, 6, 3, 1500027, 0, '', '', '2016-07-26 04:40:25'),
(2, '', 'wichanan ounjit', 'hsri', '92/14 Tantong2 Moo6 nongprao-ngai Rd.', '865401605', 'wichanan@gmail.com', 'การแพทย์แผนไทยและการแพทย์ทางเลือก', 'Proxmox Status Report', 'Proxmox Status Report Proxmox Status Report v', 'Proxmox Status ReportProxmox Status ReportProxmox Status ReportProxmox Status ReportProxmox Status Report Proxmox Status ReportProxmox Status ReportProxmox Status Report Proxmox Status Report Proxmox Status Report', '', 0, 0, 1, 1, 0, 2, 2, 2160000, 0, '', '', '2016-07-26 08:27:45'),
(3, '', 'wichanan ounjit', 'hsri', '92/14 Tantong2 Moo6 nongprao-ngai Rd.', '865401605', 'wichanan@gmail.com', 'จอยสติ๊ก เกมส์คอนโทรลเลอร์ บลูทูธไร้สาย รุ่น PG-9023 (สีดำ)', 'Proxmox Status Report', 'Proxmox Status Report Proxmox Status Report v', 'Proxmox Status ReportProxmox Status ReportProxmox Status ReportProxmox Status ReportProxmox Status Report Proxmox Status ReportProxmox Status ReportProxmox Status Report Proxmox Status Report Proxmox Status Report', '', 1, 1, 1, 1, 1, 2, 2, 2160000, 0, '', '3-จอยสติ๊ก เกมส์คอนโทรลเลอร์ บลู.doc', '2016-07-26 08:38:33'),
(4, '4301116', 'xxz', 'zxZx', 'ZxZ', 'zxczxczxc', 'xZXzx@dfdf.com', 'ZxZX', 'ZxX', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, '4-ZxZX.doc', '2016-11-30 03:06:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
